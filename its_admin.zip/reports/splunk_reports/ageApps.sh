# Find out the potential age of a Splunk app by looking for the oldest
# modtime in the local.meta and default.meta files.
# Assume that it is the creation date of the app.

# Use find to locate the local.meta and default.meta files in each of the apps.

files=`find '/opt/splunk/etc/apps' | egrep "metadata/(local|default)\.meta$"`

# Scan each file for oldest modtime

for fname in $files
do

    awk 'BEGIN {
            "date +%s" | getline tomorrow
            close(tomorrow)
            tomorrow = tomorrow + 24*60*60
            creation = tomorrow
            #print creation
        }

        /modtime/ {
            if ($3 < creation) {
                creation=$3
            }
            #print $3, creation
        }

        END {
            if (creation == creation) {
                 cmd="date -d @" creation " +%Y/%m/%d"
                 cmd | getline newd
                 close(newd)
                 split(FILENAME,subdir,"/")
                 app = subdir[6]
                 #app=FILENAME
                 print app, newd
            }

        }' $fname

done