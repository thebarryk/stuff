# Run a local bash script on a set of remote hosts

# List of hosts. Here they are OPS, ITS, FRG, HEALTH, DEV, ITSI

hosts="10.108.20.180 10.108.20.182 10.108.20.183 10.108.20.190 10.108.20.225 10.108.20.130"

# Execute the script on each of the hosts in turn

s=""
work=/tmp/ageApps_all.tmp

for host in $hosts
do

   # Here's a way to do dry runs
   #printf "%s\n" "ssh -q splunk@$host <ageApps.sh"

   # Execute the bash script. It must be complete or call programs
   # that already exist on each remote host.

    if [[ -z $s ]]
    then
        ssh -q splunk@$host <ageApps.sh >$work
        s="1"
    else
        ssh -q splunk@$host <ageApps.sh >>$work
    fi

done

sort $work | awk '
BEGIN {c=""}
{
    if ($1!=c) {
        "date -d" $2 " +%m/%d/%Y" | getline dt ;close(dt)
        print dt "," $1; c=$1; d=$2
    }
}' | egrep -v ",Splunk|,TA-|,SA-"; rm $work